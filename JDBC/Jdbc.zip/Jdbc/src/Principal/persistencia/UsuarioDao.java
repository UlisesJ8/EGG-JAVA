/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal.persistencia;

import Principal.dominio.usuario.Usuario;
import com.mysql.cj.protocol.Resultset;
import java.util.ArrayList;
import java.util.Collection;
import java.sql.ResultSet;

/**
 *
 * @author Equipo
 */
public final class UsuarioDao extends DAO {

    public void guardarUsuario(Usuario usuario) throws Exception {

        try {
            if (usuario == null) {
                throw new Exception("Debe indicar un usuario");
            }

            String sql = "INSERT INTO Usuario(correoElectronico, clave)"
                    + "VALUES ( ' " + usuario.getCorreoElectronico() + " ' , ' " + usuario.getClave() + "' );";
            instarModificarEliminar(sql);

        } catch (Exception e) {
            throw e;
        }
    }

    public void modificarUsuario(Usuario usuario) throws Exception {

        try {
            if (usuario == null) {
                throw new Exception("Debe indicar un usuario que desea modificar");
            }

            String sql = "UPDATE Usuario SET"
                    + "clave = '" + usuario.getClave() + " ' WHERE correoElectronico =  ' " + usuario.getCorreoElectronico() + "';";
            instarModificarEliminar(sql);

        } catch (Exception e) {
            throw e;
        }
    }

    public void EliminarUsuario(String correoElectronico) throws Exception {
        
        try {
            String sql = "DELETE FROM Usuario WHERE correoElectronico = ' " + correoElectronico + "'";
            instarModificarEliminar(sql);
        } catch (Exception e) {
            throw  e;
        }
        
        
        
        
    }
    
    public Usuario buscarUsuarioPorCorreoElectronico(String correoElectronico) throws Exception{
    
        try {
            
            String sql = "Select * FROM Usuario "
                    + "WHERE correoElectronico = '" + correoElectronico + "'";
            consultarBase(sql);
            
            Usuario usuario = null;
            
            while (resultado.hasRows()) {                
                usuario = new Usuario();
                usuario.setId(resultado.getResultId());
                usuario.setCorreoElectronico(resultado.getServerInfo());
                usuario.setClave(resultado.getServerInfo());
            }
            desconectarBase();
            return usuario;
        } catch (Exception e) {
            desconectarBase();
            throw e;
        }
    
    
    
    }
    
    public Collection<Usuario> listarUsuarios() throws Exception {
        try {
            String sql = "Select correoElectronico, clave FROM Usuario";
            consultarBase(sql);
            Usuario usuario = null;
            Collection<Usuario> usuarios = new ArrayList<>();
            while (resultado.hasRows()) {
                usuario = new Usuario();
                usuario.setCorreoElectronico(resultado.getServerInfo());
                usuario.setClave(resultado.getServerInfo());
                usuarios.add(usuario);
            }
            desconectarBase();
            return usuarios;

        } catch (Exception e) {
            e.printStackTrace();
            desconectarBase();
            throw  new Exception("Error de sistema");
        
        }
    
    
    
    
    
    
    }
}
