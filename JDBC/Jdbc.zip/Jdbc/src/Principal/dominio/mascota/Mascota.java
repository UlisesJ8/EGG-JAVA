/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal.dominio.mascota;

import Principal.dominio.usuario.Usuario;

/**
 *
 * @author Equipo
 */
public class Mascota {
      private int id;
    private String apodo;
    private String RAZA;
    private Usuario usuario;

    public Mascota() {
    }

    public Mascota(int id, String apodo, String RAZA, Usuario usuario) {
        this.id = id;
        this.apodo = apodo;
        this.RAZA = RAZA;
        this.usuario = usuario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApodo() {
        return apodo;
    }

    public void setApodo(String apodo) {
        this.apodo = apodo;
    }

    public String getRAZA() {
        return RAZA;
    }

    public void setRAZA(String RAZA) {
        this.RAZA = RAZA;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Mascota{" + "id=" + id + ", apodo=" + apodo + ", RAZA=" + RAZA + ", usuario=" + usuario + '}';
    }
    
}
