/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcextraprj01.dominio.comentarios;

import jdbcextraprj01.persistencias.ComentariosDAO;

/**
 *
 * @author Equipo
 */
public class ComentariosService {
    private ComentariosDAO dao;

    public ComentariosService() {
        this.dao = new ComentariosDAO();
    }
    
}
